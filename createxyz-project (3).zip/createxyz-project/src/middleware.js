import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "f6f68864-c834-4ed3-90e8-83296c6f3bc2");
  requestHeaders.set("x-createxyz-project-group-id", "410f6871-2e00-4746-819b-91a17b0a8bfe");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}