async function handler({ resumeUrl }) {
  if (!resumeUrl) {
    return { error: "Resume URL is required" };
  }

  try {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" +
        process.env.GOOGLE_GEMINI_1_5,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Please analyze the resume at this URL: ${resumeUrl}

Extract and provide the following information in JSON format:
1. All text content from the resume
2. List of technical skills mentioned
3. List of soft skills mentioned
4. Years of experience (estimate if not explicitly stated)
5. Education level and degrees
6. Job titles and companies
7. Key achievements and accomplishments
8. Industry/domain expertise
9. Certifications mentioned
10. Programming languages (if applicable)

Please return the response in this exact JSON structure:
{
  "extractedText": "full text content of the resume",
  "skills": {
    "technical": ["skill1", "skill2"],
    "soft": ["skill1", "skill2"]
  },
  "experience": {
    "years": number,
    "level": "entry/mid/senior/executive",
    "positions": [{"title": "job title", "company": "company name", "duration": "time period"}]
  },
  "education": {
    "level": "high school/bachelor/master/phd",
    "degrees": ["degree name"],
    "institutions": ["school name"]
  },
  "achievements": ["achievement1", "achievement2"],
  "certifications": ["cert1", "cert2"],
  "programmingLanguages": ["language1", "language2"],
  "industryExpertise": ["domain1", "domain2"]
}`,
                },
              ],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = await response.json();

    if (
      !data.candidates ||
      !data.candidates[0] ||
      !data.candidates[0].content
    ) {
      throw new Error("Invalid response from Gemini API");
    }

    const analysisText = data.candidates[0].content.parts[0].text;

    let analysisData;
    try {
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (parseError) {
      analysisData = {
        extractedText: analysisText,
        skills: { technical: [], soft: [] },
        experience: { years: 0, level: "unknown", positions: [] },
        education: { level: "unknown", degrees: [], institutions: [] },
        achievements: [],
        certifications: [],
        programmingLanguages: [],
        industryExpertise: [],
      };
    }

    return {
      success: true,
      extractedText: analysisData.extractedText || "",
      skills: analysisData.skills || { technical: [], soft: [] },
      experience: analysisData.experience || {
        years: 0,
        level: "unknown",
        positions: [],
      },
      education: analysisData.education || {
        level: "unknown",
        degrees: [],
        institutions: [],
      },
      achievements: analysisData.achievements || [],
      certifications: analysisData.certifications || [],
      programmingLanguages: analysisData.programmingLanguages || [],
      industryExpertise: analysisData.industryExpertise || [],
      analysis: analysisData,
    };
  } catch (error) {
    console.error("Resume analysis error:", error);
    return {
      error: "Failed to analyze resume: " + error.message,
      success: false,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}