"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [activeTab, setActiveTab] = React.useState("upload");
  const [resume, setResume] = React.useState(null);
  const [resumeText, setResumeText] = React.useState("");
  const [jobs, setJobs] = React.useState([]);
  const [matches, setMatches] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);

  const [upload, { loading: uploadLoading }] = useUpload();

  // Sample job postings
  const sampleJobs = [
    {
      id: 1,
      title: "Senior Software Engineer",
      company: "TechCorp",
      location: "San Francisco, CA",
      description:
        "We're looking for a senior software engineer with 5+ years of experience in React, Node.js, and cloud technologies. Must have experience with microservices architecture and agile development.",
      requirements: [
        "React",
        "Node.js",
        "AWS",
        "Microservices",
        "Agile",
        "JavaScript",
        "TypeScript",
      ],
    },
    {
      id: 2,
      title: "Data Scientist",
      company: "DataFlow Inc",
      location: "New York, NY",
      description:
        "Seeking a data scientist to join our analytics team. Experience with Python, machine learning, and statistical analysis required. Knowledge of SQL and data visualization tools preferred.",
      requirements: [
        "Python",
        "Machine Learning",
        "SQL",
        "Statistics",
        "Data Analysis",
        "Pandas",
        "Scikit-learn",
      ],
    },
    {
      id: 3,
      title: "Product Manager",
      company: "StartupXYZ",
      location: "Austin, TX",
      description:
        "Product manager role for a fast-growing startup. Need someone with experience in product strategy, user research, and cross-functional team leadership.",
      requirements: [
        "Product Strategy",
        "User Research",
        "Leadership",
        "Analytics",
        "Agile",
        "Roadmap Planning",
      ],
    },
  ];

  React.useEffect(() => {
    setJobs(sampleJobs);
  }, []);

  const handleResumeUpload = async (file) => {
    try {
      setLoading(true);
      setError(null);

      const { url, error: uploadError } = await upload({ file });
      if (uploadError) {
        throw new Error(uploadError);
      }

      setResume({ name: file.name, url });

      // Extract text from resume using AI
      const response = await fetch("/api/analyze-resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeUrl: url }),
      });

      if (!response.ok) {
        throw new Error("Failed to analyze resume");
      }

      const data = await response.json();
      setResumeText(data.extractedText);
      setActiveTab("matches");
    } catch (err) {
      console.error(err);
      setError("Failed to upload and analyze resume");
    } finally {
      setLoading(false);
    }
  };

  const findMatches = async () => {
    if (!resumeText) return;

    try {
      setLoading(true);
      setError(null);

      const response = await fetch("/api/find-matches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resumeText,
          jobs: jobs,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to find job matches");
      }

      const data = await response.json();
      setMatches(data.matches);
    } catch (err) {
      console.error(err);
      setError("Failed to find job matches");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (resumeText && jobs.length > 0) {
      findMatches();
    }
  }, [resumeText, jobs]);

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600 bg-green-100";
    if (score >= 60) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-gray-900 font-inter">
            <i className="fas fa-robot mr-3 text-blue-600"></i>
            AI Resume & Job Matching
          </h1>
          <p className="text-gray-600 mt-2 font-inter">
            Upload your resume and find the perfect job matches with AI-powered
            analysis
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-8">
          <button
            onClick={() => setActiveTab("upload")}
            className={`flex-1 py-2 px-4 rounded-md font-medium font-inter transition-colors ${
              activeTab === "upload"
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            <i className="fas fa-upload mr-2"></i>
            Upload Resume
          </button>
          <button
            onClick={() => setActiveTab("matches")}
            className={`flex-1 py-2 px-4 rounded-md font-medium font-inter transition-colors ${
              activeTab === "matches"
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            <i className="fas fa-search mr-2"></i>
            Job Matches
          </button>
          <button
            onClick={() => setActiveTab("jobs")}
            className={`flex-1 py-2 px-4 rounded-md font-medium font-inter transition-colors ${
              activeTab === "jobs"
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            <i className="fas fa-briefcase mr-2"></i>
            Available Jobs
          </button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <i className="fas fa-exclamation-triangle text-red-500 mr-2"></i>
              <span className="text-red-700 font-inter">{error}</span>
            </div>
          </div>
        )}

        {/* Upload Tab */}
        {activeTab === "upload" && (
          <div className="bg-white rounded-lg shadow-sm p-8">
            <div className="text-center">
              <i className="fas fa-file-upload text-6xl text-blue-500 mb-4"></i>
              <h2 className="text-2xl font-bold text-gray-900 mb-2 font-inter">
                Upload Your Resume
              </h2>
              <p className="text-gray-600 mb-8 font-inter">
                Upload your resume in PDF format and let our AI analyze it for
                job matching
              </p>

              <div className="max-w-md mx-auto">
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={(e) => {
                    const file = e.target.files[0];
                    if (file) handleResumeUpload(file);
                  }}
                  className="hidden"
                  id="resume-upload"
                />
                <label
                  htmlFor="resume-upload"
                  className={`block w-full py-3 px-6 border-2 border-dashed border-blue-300 rounded-lg cursor-pointer hover:border-blue-400 transition-colors font-inter ${
                    loading || uploadLoading
                      ? "opacity-50 cursor-not-allowed"
                      : ""
                  }`}
                >
                  {loading || uploadLoading ? (
                    <div className="flex items-center justify-center">
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Analyzing Resume...
                    </div>
                  ) : (
                    <div>
                      <i className="fas fa-cloud-upload-alt text-2xl text-blue-500 mb-2"></i>
                      <div className="text-blue-600 font-medium">
                        Click to upload resume
                      </div>
                      <div className="text-gray-500 text-sm">
                        PDF, DOC, or DOCX files
                      </div>
                    </div>
                  )}
                </label>
              </div>

              {resume && (
                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center justify-center">
                    <i className="fas fa-check-circle text-green-500 mr-2"></i>
                    <span className="text-green-700 font-inter">
                      Resume uploaded: {resume.name}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Job Matches Tab */}
        {activeTab === "matches" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 font-inter">
                <i className="fas fa-bullseye mr-2 text-blue-600"></i>
                Your Job Matches
              </h2>
              {resumeText && (
                <button
                  onClick={findMatches}
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-inter"
                >
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Finding Matches...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-sync mr-2"></i>
                      Refresh Matches
                    </>
                  )}
                </button>
              )}
            </div>

            {!resumeText ? (
              <div className="bg-white rounded-lg shadow-sm p-8 text-center">
                <i className="fas fa-file-alt text-4xl text-gray-400 mb-4"></i>
                <h3 className="text-xl font-semibold text-gray-700 mb-2 font-inter">
                  No Resume Uploaded
                </h3>
                <p className="text-gray-500 mb-4 font-inter">
                  Please upload your resume first to see job matches
                </p>
                <button
                  onClick={() => setActiveTab("upload")}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-inter"
                >
                  Upload Resume
                </button>
              </div>
            ) : matches.length === 0 && !loading ? (
              <div className="bg-white rounded-lg shadow-sm p-8 text-center">
                <i className="fas fa-search text-4xl text-gray-400 mb-4"></i>
                <h3 className="text-xl font-semibold text-gray-700 mb-2 font-inter">
                  Finding Matches...
                </h3>
                <p className="text-gray-500 font-inter">
                  Our AI is analyzing your resume to find the best job matches
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {matches.map((match, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-blue-500"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 font-inter">
                          {match.job.title}
                        </h3>
                        <p className="text-gray-600 font-inter">
                          <i className="fas fa-building mr-1"></i>
                          {match.job.company} • {match.job.location}
                        </p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreColor(
                          match.score
                        )}`}
                      >
                        {match.score}% Match
                      </div>
                    </div>

                    <p className="text-gray-700 mb-4 font-inter">
                      {match.job.description}
                    </p>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2 font-inter">
                          <i className="fas fa-check-circle text-green-500 mr-1"></i>
                          Matching Skills
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {match.matchingSkills?.map((skill, i) => (
                            <span
                              key={i}
                              className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm font-inter"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2 font-inter">
                          <i className="fas fa-exclamation-circle text-orange-500 mr-1"></i>
                          Skills to Develop
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {match.missingSkills?.map((skill, i) => (
                            <span
                              key={i}
                              className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-inter"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {match.recommendation && (
                      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                        <h4 className="font-semibold text-blue-900 mb-1 font-inter">
                          <i className="fas fa-lightbulb mr-1"></i>
                          AI Recommendation
                        </h4>
                        <p className="text-blue-800 text-sm font-inter">
                          {match.recommendation}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Available Jobs Tab */}
        {activeTab === "jobs" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 font-inter">
                <i className="fas fa-briefcase mr-2 text-blue-600"></i>
                Available Positions
              </h2>
              <div className="text-gray-600 font-inter">
                {jobs.length} jobs available
              </div>
            </div>

            <div className="grid gap-6">
              {jobs.map((job) => (
                <div key={job.id} className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 font-inter">
                        {job.title}
                      </h3>
                      <p className="text-gray-600 font-inter">
                        <i className="fas fa-building mr-1"></i>
                        {job.company} • {job.location}
                      </p>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-4 font-inter">
                    {job.description}
                  </p>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2 font-inter">
                      Required Skills
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {job.requirements.map((req, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-inter"
                        >
                          {req}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;