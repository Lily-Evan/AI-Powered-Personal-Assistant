async function handler({ message, conversationHistory = [], context = {} }) {
  if (!message || typeof message !== "string") {
    return {
      error: "Message is required and must be a string",
      success: false,
    };
  }

  try {
    const systemPrompt = `You are a helpful AI assistant integrated into a personal productivity dashboard. You can help users with:

1. General conversation and questions
2. Task creation and management
3. Scheduling and time management
4. Resume and job matching advice
5. Personal productivity tips
6. Data analysis and insights

Context about the user's current session:
- Current page: ${context.currentPage || "unknown"}
- User preferences: ${JSON.stringify(context.userPreferences || {})}
- Available features: Resume analysis, job matching, task management

Be conversational, helpful, and provide actionable advice when appropriate. If the user asks about features available in this app, guide them accordingly.`;

    const messages = [
      {
        role: "system",
        content: systemPrompt,
      },
    ];

    if (conversationHistory && Array.isArray(conversationHistory)) {
      conversationHistory.forEach((msg) => {
        if (msg.role && msg.content) {
          messages.push({
            role: msg.role === "user" ? "user" : "assistant",
            content: msg.content,
          });
        }
      });
    }

    messages.push({
      role: "user",
      content: message,
    });

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_CLAUDE_SONNET_3_5,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-5-sonnet-20241022",
        max_tokens: 1000,
        messages: messages.filter((msg) => msg.role !== "system"),
        system: systemPrompt,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`Claude API error: ${response.status} - ${errorData}`);
    }

    const data = await response.json();

    if (
      !data.content ||
      !Array.isArray(data.content) ||
      data.content.length === 0
    ) {
      throw new Error("Invalid response format from Claude API");
    }

    const aiResponse = data.content[0].text;

    const responseType = determineResponseType(message, aiResponse);

    return {
      success: true,
      response: aiResponse,
      responseType: responseType,
      conversationId: context.conversationId || generateConversationId(),
      timestamp: new Date().toISOString(),
      usage: {
        inputTokens: data.usage?.input_tokens || 0,
        outputTokens: data.usage?.output_tokens || 0,
      },
      suggestions: generateSuggestions(responseType, context),
      metadata: {
        model: "claude-3-5-sonnet",
        processingTime: Date.now(),
      },
    };
  } catch (error) {
    console.error("AI Chat Handler error:", error);

    return {
      error: "Failed to process your message. Please try again.",
      success: false,
      fallbackResponse: generateFallbackResponse(message),
      timestamp: new Date().toISOString(),
      errorType: error.message.includes("API")
        ? "api_error"
        : "processing_error",
    };
  }
}

function determineResponseType(userMessage, aiResponse) {
  const message = userMessage.toLowerCase();
  const response = aiResponse.toLowerCase();

  if (
    message.includes("task") ||
    message.includes("todo") ||
    message.includes("remind")
  ) {
    return "task_management";
  }

  if (
    message.includes("schedule") ||
    message.includes("calendar") ||
    message.includes("meeting")
  ) {
    return "scheduling";
  }

  if (
    message.includes("resume") ||
    message.includes("job") ||
    message.includes("career")
  ) {
    return "career_advice";
  }

  if (
    message.includes("analyze") ||
    message.includes("data") ||
    message.includes("report")
  ) {
    return "analysis";
  }

  return "general_chat";
}

function generateSuggestions(responseType, context) {
  const suggestions = {
    task_management: [
      "Create a new task",
      "Show my task list",
      "Set a reminder",
      "Mark task as complete",
    ],
    scheduling: [
      "Check my calendar",
      "Schedule a meeting",
      "Set an appointment",
      "View upcoming events",
    ],
    career_advice: [
      "Upload my resume",
      "Find job matches",
      "Analyze my skills",
      "Get career tips",
    ],
    analysis: [
      "Generate a report",
      "Analyze my data",
      "Show insights",
      "Create charts",
    ],
    general_chat: [
      "Help me be more productive",
      "What can you do?",
      "Show me my dashboard",
      "Give me tips for today",
    ],
  };

  return suggestions[responseType] || suggestions.general_chat;
}

function generateFallbackResponse(message) {
  const fallbacks = [
    "I'm having trouble processing your request right now. Could you try rephrasing your question?",
    "Sorry, I'm experiencing some technical difficulties. Please try again in a moment.",
    "I'm not able to respond properly at the moment. Is there something specific I can help you with?",
    "My AI processing is temporarily unavailable. Would you like to try a different approach?",
  ];

  return fallbacks[Math.floor(Math.random() * fallbacks.length)];
}

function generateConversationId() {
  return "conv_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
}
export async function POST(request) {
  return handler(await request.json());
}