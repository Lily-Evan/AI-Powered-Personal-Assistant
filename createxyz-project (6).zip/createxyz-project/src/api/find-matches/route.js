async function handler({ resumeText, jobs }) {
  if (!resumeText || !jobs || !Array.isArray(jobs)) {
    return { error: "Resume text and jobs array are required" };
  }

  try {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" +
        process.env.GOOGLE_GEMINI_1_5,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Please analyze the compatibility between this resume and the following job postings. 

RESUME TEXT:
${resumeText}

JOB POSTINGS:
${JSON.stringify(jobs, null, 2)}

For each job posting, provide a detailed analysis including:
1. Match score (0-100) based on skills, experience, and requirements alignment
2. List of matching skills found in both resume and job requirements
3. List of missing skills that the candidate should develop
4. Personalized recommendation explaining why this is or isn't a good match
5. Specific advice for improving candidacy for this role

Please return the response in this exact JSON structure:
{
  "matches": [
    {
      "jobId": "job id from the posting",
      "job": {job object from input},
      "score": number between 0-100,
      "matchingSkills": ["skill1", "skill2"],
      "missingSkills": ["skill1", "skill2"],
      "recommendation": "detailed personalized recommendation text",
      "strengthsAlignment": ["strength1", "strength2"],
      "improvementAreas": ["area1", "area2"],
      "fitReason": "brief explanation of why this is a good/poor fit"
    }
  ],
  "overallSummary": "summary of candidate's profile and general job market fit"
}

Rank the matches by score from highest to lowest. Be thorough in your analysis and provide actionable insights.`,
                },
              ],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = await response.json();

    if (
      !data.candidates ||
      !data.candidates[0] ||
      !data.candidates[0].content
    ) {
      throw new Error("Invalid response from Gemini API");
    }

    const analysisText = data.candidates[0].content.parts[0].text;

    let matchData;
    try {
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        matchData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (parseError) {
      matchData = {
        matches: jobs.map((job, index) => ({
          jobId: job.id || index,
          job: job,
          score: Math.floor(Math.random() * 40) + 30,
          matchingSkills: [],
          missingSkills: job.requirements || [],
          recommendation:
            "Unable to parse detailed analysis. Please try again.",
          strengthsAlignment: [],
          improvementAreas: job.requirements || [],
          fitReason: "Analysis unavailable",
        })),
        overallSummary: "Analysis could not be completed. Please try again.",
      };
    }

    if (!matchData.matches || !Array.isArray(matchData.matches)) {
      matchData.matches = jobs.map((job, index) => ({
        jobId: job.id || index,
        job: job,
        score: 50,
        matchingSkills: [],
        missingSkills: job.requirements || [],
        recommendation: "Match analysis unavailable",
        strengthsAlignment: [],
        improvementAreas: [],
        fitReason: "Unable to determine fit",
      }));
    }

    matchData.matches.sort((a, b) => b.score - a.score);

    return {
      success: true,
      matches: matchData.matches,
      overallSummary:
        matchData.overallSummary || "Job matching analysis completed",
      totalJobs: jobs.length,
      averageScore:
        matchData.matches.reduce((sum, match) => sum + match.score, 0) /
        matchData.matches.length,
    };
  } catch (error) {
    console.error("Job matching error:", error);
    return {
      error: "Failed to analyze job matches: " + error.message,
      success: false,
      matches: jobs.map((job, index) => ({
        jobId: job.id || index,
        job: job,
        score: 0,
        matchingSkills: [],
        missingSkills: job.requirements || [],
        recommendation: "Analysis failed. Please try again.",
        strengthsAlignment: [],
        improvementAreas: [],
        fitReason: "Error occurred during analysis",
      })),
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}