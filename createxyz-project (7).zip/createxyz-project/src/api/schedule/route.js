async function handler({
  scheduleRequest,
  existingEvents = [],
  userPreferences = {},
  timeZone = "UTC",
}) {
  if (!scheduleRequest || typeof scheduleRequest !== "string") {
    return {
      error: "Schedule request is required and must be a string",
      success: false,
    };
  }

  try {
    const systemPrompt = `You are an AI scheduling assistant. Your job is to parse natural language scheduling requests and provide intelligent scheduling recommendations.

Analyze the user's scheduling request and provide:
1. Event details (title, duration, type)
2. Optimal time slots based on existing calendar
3. Handle conflicts and suggest alternatives
4. Create recurring patterns if needed
5. Smart defaults for meeting types
6. Time zone considerations
7. Availability preferences

Current Context:
- User timezone: ${timeZone}
- Current date/time: ${new Date().toISOString()}
- User preferences: ${JSON.stringify(userPreferences)}
- Existing events count: ${existingEvents.length}

User Preferences Context:
- Work hours: ${userPreferences.workHours || "9:00 AM - 5:00 PM"}
- Preferred meeting duration: ${
      userPreferences.defaultMeetingDuration || "30 minutes"
    }
- Buffer time between meetings: ${userPreferences.bufferTime || "15 minutes"}
- Preferred days: ${userPreferences.preferredDays || "Monday-Friday"}
- Avoid scheduling during: ${userPreferences.blockedTimes || "lunch hours"}

Return response in this exact JSON structure:
{
  "event": {
    "title": "clear event title",
    "description": "detailed description",
    "duration": "duration in minutes",
    "type": "meeting|appointment|task|reminder|block",
    "priority": "high|medium|low",
    "location": "location or 'virtual'",
    "attendees": ["email1", "email2"] or [],
    "recurring": {
      "pattern": "daily|weekly|monthly|yearly|none",
      "frequency": 1,
      "endDate": "YYYY-MM-DD or null",
      "daysOfWeek": [1,2,3,4,5] or null
    }
  },
  "suggestedTimes": [
    {
      "startTime": "YYYY-MM-DDTHH:mm:ss.sssZ",
      "endTime": "YYYY-MM-DDTHH:mm:ss.sssZ",
      "confidence": 0.95,
      "reason": "why this time is optimal",
      "conflicts": []
    }
  ],
  "alternatives": [
    {
      "startTime": "YYYY-MM-DDTHH:mm:ss.sssZ",
      "endTime": "YYYY-MM-DDTHH:mm:ss.sssZ",
      "confidence": 0.80,
      "reason": "alternative option explanation"
    }
  ],
  "conflicts": [
    {
      "conflictingEvent": "event title",
      "conflictTime": "time range",
      "severity": "high|medium|low",
      "suggestion": "how to resolve"
    }
  ],
  "recommendations": {
    "bestTimeSlot": "explanation of recommended time",
    "preparation": ["prep item 1", "prep item 2"],
    "followUp": ["follow-up action 1", "follow-up action 2"],
    "optimizations": ["optimization 1", "optimization 2"]
  },
  "analysis": {
    "requestType": "new_meeting|reschedule|recurring|block_time",
    "urgency": "immediate|this_week|flexible",
    "complexity": "simple|moderate|complex",
    "stakeholders": ["person1", "person2"]
  }
}

Be smart about parsing context:
- "Meeting with John tomorrow at 2pm" → specific time, create event
- "Schedule weekly team standup" → recurring weekly meeting
- "Find time for 1-hour project review this week" → find optimal slot
- "Block 2 hours for deep work" → focus time block
- "Reschedule the client call to next week" → move existing event`;

    const existingEventsContext =
      existingEvents.length > 0
        ? `\n\nExisting Calendar Events:\n${existingEvents
            .map(
              (event) =>
                `- ${event.title || "Untitled"}: ${
                  event.startTime || "No time"
                } to ${event.endTime || "No end"}`
            )
            .join("\n")}`
        : "\n\nNo existing events provided.";

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_CLAUDE_SONNET_3_5,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-5-sonnet-20241022",
        max_tokens: 2000,
        messages: [
          {
            role: "user",
            content: `Parse this scheduling request: "${scheduleRequest}"${existingEventsContext}`,
          },
        ],
        system: systemPrompt,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`Claude API error: ${response.status} - ${errorData}`);
    }

    const data = await response.json();

    if (
      !data.content ||
      !Array.isArray(data.content) ||
      data.content.length === 0
    ) {
      throw new Error("Invalid response format from Claude API");
    }

    const aiResponse = data.content[0].text;

    let scheduleData;
    try {
      const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        scheduleData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in AI response");
      }
    } catch (parseError) {
      scheduleData = createFallbackSchedule(scheduleRequest, timeZone);
    }

    if (!scheduleData.event) {
      scheduleData.event = createFallbackEvent(scheduleRequest);
    }

    scheduleData.event.id = generateEventId();
    scheduleData.event.createdAt = new Date().toISOString();
    scheduleData.event.timeZone = timeZone;

    const processedConflicts = detectConflicts(
      scheduleData.suggestedTimes || [],
      existingEvents
    );

    const optimizedTimes = optimizeTimeSlots(
      scheduleData.suggestedTimes || [],
      userPreferences,
      timeZone
    );

    return {
      success: true,
      event: scheduleData.event,
      suggestedTimes: optimizedTimes,
      alternatives: scheduleData.alternatives || [],
      conflicts: processedConflicts,
      recommendations: scheduleData.recommendations || {},
      analysis: scheduleData.analysis || {},
      originalRequest: scheduleRequest,
      processingTime: Date.now(),
      aiConfidence: calculateSchedulingConfidence(
        scheduleRequest,
        scheduleData
      ),
      metadata: {
        model: "claude-3-5-sonnet",
        timestamp: new Date().toISOString(),
        timeZone: timeZone,
        userPreferences: userPreferences,
      },
    };
  } catch (error) {
    console.error("Scheduling assistant error:", error);

    const fallbackSchedule = createFallbackSchedule(scheduleRequest, timeZone);

    return {
      error: "AI scheduling failed, created basic schedule structure",
      success: false,
      event: fallbackSchedule.event,
      suggestedTimes: fallbackSchedule.suggestedTimes,
      alternatives: [],
      conflicts: [],
      recommendations: {
        bestTimeSlot: "Please manually review and adjust timing",
        preparation: ["Review calendar for conflicts"],
        followUp: ["Confirm with attendees"],
        optimizations: ["Consider user preferences"],
      },
      fallback: true,
      originalRequest: scheduleRequest,
      errorType: error.message.includes("API")
        ? "api_error"
        : "processing_error",
      timestamp: new Date().toISOString(),
    };
  }
}

function createFallbackSchedule(request, timeZone) {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(10, 0, 0, 0);

  const endTime = new Date(tomorrow);
  endTime.setHours(11, 0, 0, 0);

  return {
    event: {
      id: generateEventId(),
      title: request.length > 50 ? request.substring(0, 50) + "..." : request,
      description: request,
      duration: 60,
      type: "meeting",
      priority: "medium",
      location: "virtual",
      attendees: [],
      recurring: {
        pattern: "none",
        frequency: 1,
        endDate: null,
        daysOfWeek: null,
      },
      createdAt: new Date().toISOString(),
      timeZone: timeZone,
    },
    suggestedTimes: [
      {
        startTime: tomorrow.toISOString(),
        endTime: endTime.toISOString(),
        confidence: 0.5,
        reason: "Default fallback time slot",
        conflicts: [],
      },
    ],
  };
}

function createFallbackEvent(request) {
  return {
    id: generateEventId(),
    title: request.length > 50 ? request.substring(0, 50) + "..." : request,
    description: request,
    duration: 60,
    type: "meeting",
    priority: "medium",
    location: "virtual",
    attendees: [],
    recurring: {
      pattern: "none",
      frequency: 1,
      endDate: null,
      daysOfWeek: null,
    },
    createdAt: new Date().toISOString(),
  };
}

function detectConflicts(suggestedTimes, existingEvents) {
  const conflicts = [];

  suggestedTimes.forEach((timeSlot) => {
    const slotStart = new Date(timeSlot.startTime);
    const slotEnd = new Date(timeSlot.endTime);

    existingEvents.forEach((event) => {
      if (!event.startTime || !event.endTime) return;

      const eventStart = new Date(event.startTime);
      const eventEnd = new Date(event.endTime);

      if (slotStart < eventEnd && slotEnd > eventStart) {
        conflicts.push({
          conflictingEvent: event.title || "Untitled Event",
          conflictTime: `${eventStart.toLocaleTimeString()} - ${eventEnd.toLocaleTimeString()}`,
          severity: "high",
          suggestion: "Consider scheduling before or after this event",
        });
      }
    });
  });

  return conflicts;
}

function optimizeTimeSlots(timeSlots, preferences, timeZone) {
  if (!timeSlots || timeSlots.length === 0) return [];

  return timeSlots
    .map((slot) => {
      const startTime = new Date(slot.startTime);
      const hour = startTime.getHours();

      let confidence = slot.confidence || 0.5;

      if (preferences.workHours) {
        const workStart = parseInt(preferences.workHours.split("-")[0]) || 9;
        const workEnd = parseInt(preferences.workHours.split("-")[1]) || 17;

        if (hour >= workStart && hour <= workEnd) {
          confidence += 0.2;
        } else {
          confidence -= 0.3;
        }
      }

      if (preferences.preferredDays) {
        const dayOfWeek = startTime.getDay();
        const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;

        if (preferences.preferredDays.includes("Monday-Friday") && isWeekday) {
          confidence += 0.1;
        }
      }

      return {
        ...slot,
        confidence: Math.max(0, Math.min(1, confidence)),
      };
    })
    .sort((a, b) => b.confidence - a.confidence);
}

function calculateSchedulingConfidence(request, scheduleData) {
  let confidence = 0.5;

  if (
    scheduleData.event &&
    scheduleData.event.title &&
    scheduleData.event.title.length > 0
  ) {
    confidence += 0.2;
  }

  if (scheduleData.suggestedTimes && scheduleData.suggestedTimes.length > 0) {
    confidence += 0.2;
  }

  if (
    scheduleData.event &&
    scheduleData.event.duration &&
    scheduleData.event.duration > 0
  ) {
    confidence += 0.1;
  }

  if (
    scheduleData.recommendations &&
    Object.keys(scheduleData.recommendations).length > 0
  ) {
    confidence += 0.1;
  }

  return Math.min(confidence, 1.0);
}

function generateEventId() {
  return "event_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
}
export async function POST(request) {
  return handler(await request.json());
}