"use client";
import React from "react";

function MainComponent() {
  const [activeSection, setActiveSection] = React.useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = React.useState(true);
  const [darkMode, setDarkMode] = React.useState(false);
  const [user, setUser] = React.useState({ name: "User", avatar: null });

  // Chat state
  const [messages, setMessages] = React.useState([
    {
      id: 1,
      type: "ai",
      content: "Hello! I'm your AI assistant. How can I help you today?",
      timestamp: new Date(),
    },
  ]);
  const [currentMessage, setCurrentMessage] = React.useState("");
  const [isTyping, setIsTyping] = React.useState(false);
  const [isListening, setIsListening] = React.useState(false);
  const [conversationId, setConversationId] = React.useState(null);

  // Task management state
  const [tasks, setTasks] = React.useState([
    {
      id: 1,
      title: "Review quarterly reports",
      completed: false,
      priority: "high",
      category: "work",
      dueDate: "2025-01-15",
      createdAt: new Date(),
    },
    {
      id: 2,
      title: "Schedule dentist appointment",
      completed: false,
      priority: "medium",
      category: "personal",
      dueDate: "2025-01-20",
      createdAt: new Date(),
    },
  ]);
  const [newTask, setNewTask] = React.useState("");
  const [taskFilter, setTaskFilter] = React.useState("all");

  // Calendar state
  const [events, setEvents] = React.useState([
    {
      id: 1,
      title: "Team Meeting",
      date: "2025-01-15",
      time: "10:00",
      type: "meeting",
    },
    {
      id: 2,
      title: "Doctor Appointment",
      date: "2025-01-16",
      time: "14:30",
      type: "appointment",
    },
  ]);
  const [newEvent, setNewEvent] = React.useState({
    title: "",
    date: "",
    time: "",
    type: "meeting",
  });

  // Notes state
  const [notes, setNotes] = React.useState([
    {
      id: 1,
      title: "Project Ideas",
      content: "AI-powered productivity tools, Smart home automation",
      category: "ideas",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      title: "Meeting Notes",
      content: "Discussed Q1 goals and budget allocation",
      category: "work",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]);
  const [newNote, setNewNote] = React.useState({
    title: "",
    content: "",
    category: "general",
  });
  const [noteSearch, setNoteSearch] = React.useState("");

  // Email state
  const [emails, setEmails] = React.useState([
    {
      id: 1,
      from: "john@company.com",
      subject: "Project Update",
      preview: "The latest project status...",
      read: false,
      timestamp: new Date(),
    },
    {
      id: 2,
      from: "sarah@client.com",
      subject: "Meeting Confirmation",
      preview: "Confirming our meeting...",
      read: true,
      timestamp: new Date(),
    },
  ]);
  const [emailDraft, setEmailDraft] = React.useState({
    to: "",
    subject: "",
    body: "",
  });

  // Weather state
  const [weather, setWeather] = React.useState({
    location: "New York, NY",
    temperature: 22,
    condition: "Partly Cloudy",
    humidity: 65,
    windSpeed: 12,
    forecast: [
      { day: "Today", high: 25, low: 18, condition: "Partly Cloudy" },
      { day: "Tomorrow", high: 28, low: 20, condition: "Sunny" },
      { day: "Thursday", high: 24, low: 16, condition: "Rainy" },
    ],
  });

  // News state
  const [news, setNews] = React.useState([
    {
      id: 1,
      title: "Tech Industry Updates",
      summary: "Latest developments in AI and technology sector...",
      source: "Tech News",
      timestamp: new Date(),
    },
    {
      id: 2,
      title: "Market Analysis",
      summary: "Stock market trends and economic indicators...",
      source: "Financial Times",
      timestamp: new Date(),
    },
  ]);

  // Habits state
  const [habits, setHabits] = React.useState([
    {
      id: 1,
      name: "Exercise",
      target: 5,
      completed: 3,
      streak: 12,
      category: "health",
    },
    {
      id: 2,
      name: "Read",
      target: 7,
      completed: 5,
      streak: 8,
      category: "learning",
    },
    {
      id: 3,
      name: "Meditate",
      target: 7,
      completed: 4,
      streak: 15,
      category: "wellness",
    },
  ]);

  // Goals state
  const [goals, setGoals] = React.useState([
    {
      id: 1,
      title: "Learn Spanish",
      progress: 65,
      target: 100,
      category: "learning",
      deadline: "2025-06-01",
    },
    {
      id: 2,
      title: "Run Marathon",
      progress: 30,
      target: 100,
      category: "fitness",
      deadline: "2025-10-15",
    },
  ]);

  // Analytics state
  const [analytics, setAnalytics] = React.useState({
    tasksCompleted: 45,
    averageProductivity: 78,
    streakDays: 12,
    totalNotes: 23,
    emailsProcessed: 156,
  });

  // Speech recognition setup
  React.useEffect(() => {
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = "en-US";

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setCurrentMessage(transcript);
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      window.speechRecognition = recognition;
    }
  }, []);

  const startListening = () => {
    if (window.speechRecognition) {
      setIsListening(true);
      window.speechRecognition.start();
    }
  };

  const sendMessage = async () => {
    if (!currentMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      type: "user",
      content: currentMessage,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    const messageToSend = currentMessage;
    setCurrentMessage("");
    setIsTyping(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: messageToSend,
          conversationHistory: messages.slice(-10).map((msg) => ({
            role: msg.type === "user" ? "user" : "assistant",
            content: msg.content,
          })),
          context: {
            currentPage: activeSection,
            conversationId: conversationId,
            userPreferences: {
              timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
              workHours: "9:00 AM - 5:00 PM",
            },
          },
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to get AI response");
      }

      const data = await response.json();

      if (data.success) {
        const aiMessage = {
          id: Date.now() + 1,
          type: "ai",
          content: data.response,
          timestamp: new Date(),
          responseType: data.responseType,
          suggestions: data.suggestions,
        };

        setMessages((prev) => [...prev, aiMessage]);

        if (data.conversationId && !conversationId) {
          setConversationId(data.conversationId);
        }
      } else {
        throw new Error(data.error || "AI response failed");
      }
    } catch (error) {
      console.error("AI response error:", error);
      const errorMessage = {
        id: Date.now() + 1,
        type: "ai",
        content:
          data?.fallbackResponse ||
          "I apologize, but I encountered an error. Please try again.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const addTask = async () => {
    if (!newTask.trim()) return;

    try {
      const response = await fetch("/api/create-task", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          taskDescription: newTask,
          userContext: {
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            workSchedule: "Standard business hours",
          },
          existingTasks: tasks.map((t) => ({
            title: t.title,
            category: t.category,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to create task");
      }

      const data = await response.json();

      if (data.success && data.task) {
        const newTaskData = {
          id: Date.now(),
          title: data.task.title,
          completed: false,
          priority: data.task.priority || "medium",
          category: data.task.category || "general",
          dueDate: data.task.dueDate || "",
          createdAt: new Date(),
          description: data.task.description,
          estimatedDuration: data.task.estimatedDuration,
          tags: data.task.tags || [],
          subtasks: data.task.subtasks || [],
        };

        setTasks((prev) => [...prev, newTaskData]);
        setNewTask("");

        // Show AI suggestions if available
        if (data.suggestions && data.suggestions.relatedTasks) {
          console.log(
            "AI suggests related tasks:",
            data.suggestions.relatedTasks
          );
        }
      } else {
        // Fallback to simple task creation
        const task = {
          id: Date.now(),
          title: newTask,
          completed: false,
          priority: "medium",
          category: "general",
          dueDate: "",
          createdAt: new Date(),
        };
        setTasks((prev) => [...prev, task]);
        setNewTask("");
      }
    } catch (error) {
      console.error("Task creation error:", error);
      // Fallback to simple task creation
      const task = {
        id: Date.now(),
        title: newTask,
        completed: false,
        priority: "medium",
        category: "general",
        dueDate: "",
        createdAt: new Date(),
      };
      setTasks((prev) => [...prev, task]);
      setNewTask("");
    }
  };

  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const addEvent = async () => {
    if (!newEvent.title || !newEvent.date) return;

    try {
      const scheduleRequest = `${newEvent.title} on ${newEvent.date}${
        newEvent.time ? ` at ${newEvent.time}` : ""
      } (${newEvent.type})`;

      const response = await fetch("/api/schedule", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          scheduleRequest: scheduleRequest,
          existingEvents: events.map((e) => ({
            title: e.title,
            startTime: `${e.date}T${e.time || "00:00"}:00.000Z`,
            endTime: `${e.date}T${e.time || "01:00"}:00.000Z`,
          })),
          userPreferences: {
            workHours: "9:00 AM - 5:00 PM",
            defaultMeetingDuration: "30 minutes",
            bufferTime: "15 minutes",
            preferredDays: "Monday-Friday",
          },
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to create event");
      }

      const data = await response.json();

      if (data.success && data.event) {
        const event = {
          id: Date.now(),
          title: data.event.title,
          date: newEvent.date,
          time: newEvent.time,
          type: data.event.type || newEvent.type,
          duration: data.event.duration,
          description: data.event.description,
          location: data.event.location,
        };

        setEvents((prev) => [...prev, event]);
        setNewEvent({ title: "", date: "", time: "", type: "meeting" });

        // Show AI recommendations if available
        if (data.recommendations && data.recommendations.bestTimeSlot) {
          console.log("AI recommends:", data.recommendations.bestTimeSlot);
        }
      } else {
        // Fallback to simple event creation
        const event = {
          id: Date.now(),
          ...newEvent,
        };
        setEvents((prev) => [...prev, event]);
        setNewEvent({ title: "", date: "", time: "", type: "meeting" });
      }
    } catch (error) {
      console.error("Event creation error:", error);
      // Fallback to simple event creation
      const event = {
        id: Date.now(),
        ...newEvent,
      };
      setEvents((prev) => [...prev, event]);
      setNewEvent({ title: "", date: "", time: "", type: "meeting" });
    }
  };

  const addNote = () => {
    if (!newNote.title || !newNote.content) return;
    const note = {
      id: Date.now(),
      ...newNote,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setNotes((prev) => [...prev, note]);
    setNewNote({ title: "", content: "", category: "general" });
  };

  const filteredTasks = tasks.filter((task) => {
    if (taskFilter === "completed") return task.completed;
    if (taskFilter === "pending") return !task.completed;
    return true;
  });

  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(noteSearch.toLowerCase()) ||
      note.content.toLowerCase().includes(noteSearch.toLowerCase())
  );

  const sidebarItems = [
    { id: "dashboard", icon: "fas fa-tachometer-alt", label: "Dashboard" },
    { id: "chat", icon: "fas fa-comments", label: "AI Chat" },
    { id: "tasks", icon: "fas fa-tasks", label: "Tasks" },
    { id: "calendar", icon: "fas fa-calendar", label: "Calendar" },
    { id: "notes", icon: "fas fa-sticky-note", label: "Notes" },
    { id: "email", icon: "fas fa-envelope", label: "Email" },
    { id: "weather", icon: "fas fa-cloud-sun", label: "Weather" },
    { id: "news", icon: "fas fa-newspaper", label: "News" },
    { id: "habits", icon: "fas fa-chart-line", label: "Habits" },
    { id: "goals", icon: "fas fa-bullseye", label: "Goals" },
    { id: "analytics", icon: "fas fa-chart-bar", label: "Analytics" },
  ];

  const quickActions = [
    {
      icon: "fas fa-plus",
      label: "Add Task",
      action: () => setActiveSection("tasks"),
    },
    {
      icon: "fas fa-calendar-plus",
      label: "Schedule",
      action: () => setActiveSection("calendar"),
    },
    {
      icon: "fas fa-sticky-note",
      label: "New Note",
      action: () => setActiveSection("notes"),
    },
    { icon: "fas fa-microphone", label: "Voice", action: startListening },
  ];

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900 font-inter">
          Good morning, {user.name}!
        </h1>
        <div className="flex space-x-2">
          {quickActions.map((action, index) => (
            <button
              key={index}
              onClick={action.action}
              className="p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              title={action.label}
            >
              <i className={action.icon}></i>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-inter">Tasks Today</p>
              <p className="text-2xl font-bold text-gray-900 font-inter">
                {tasks.filter((t) => !t.completed).length}
              </p>
            </div>
            <i className="fas fa-tasks text-blue-600 text-2xl"></i>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-inter">Productivity</p>
              <p className="text-2xl font-bold text-gray-900 font-inter">
                {analytics.averageProductivity}%
              </p>
            </div>
            <i className="fas fa-chart-line text-green-600 text-2xl"></i>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-inter">Streak Days</p>
              <p className="text-2xl font-bold text-gray-900 font-inter">
                {analytics.streakDays}
              </p>
            </div>
            <i className="fas fa-fire text-orange-600 text-2xl"></i>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-inter">Weather</p>
              <p className="text-2xl font-bold text-gray-900 font-inter">
                {weather.temperature}°C
              </p>
            </div>
            <i className="fas fa-cloud-sun text-yellow-600 text-2xl"></i>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
            <i className="fas fa-tasks mr-2 text-blue-600"></i>
            Recent Tasks
          </h3>
          <div className="space-y-3">
            {tasks.slice(0, 5).map((task) => (
              <div key={task.id} className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTask(task.id)}
                  className="rounded"
                />
                <span
                  className={`font-inter ${
                    task.completed
                      ? "line-through text-gray-500"
                      : "text-gray-900"
                  }`}
                >
                  {task.title}
                </span>
                <span
                  className={`px-2 py-1 rounded-full text-xs font-inter ${
                    task.priority === "high"
                      ? "bg-red-100 text-red-800"
                      : task.priority === "medium"
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-green-100 text-green-800"
                  }`}
                >
                  {task.priority}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
            <i className="fas fa-calendar mr-2 text-blue-600"></i>
            Upcoming Events
          </h3>
          <div className="space-y-3">
            {events.slice(0, 5).map((event) => (
              <div key={event.id} className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900 font-inter">
                    {event.title}
                  </p>
                  <p className="text-sm text-gray-600 font-inter">
                    {event.date} at {event.time}
                  </p>
                </div>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-inter">
                  {event.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
            <i className="fas fa-chart-line mr-2 text-blue-600"></i>
            Habit Progress
          </h3>
          <div className="space-y-4">
            {habits.map((habit) => (
              <div key={habit.id}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium text-gray-900 font-inter">
                    {habit.name}
                  </span>
                  <span className="text-sm text-gray-600 font-inter">
                    {habit.completed}/{habit.target}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{
                      width: `${(habit.completed / habit.target) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
            <i className="fas fa-newspaper mr-2 text-blue-600"></i>
            Latest News
          </h3>
          <div className="space-y-3">
            {news.map((article) => (
              <div key={article.id}>
                <h4 className="font-medium text-gray-900 font-inter text-sm">
                  {article.title}
                </h4>
                <p className="text-xs text-gray-600 font-inter">
                  {article.summary}
                </p>
                <p className="text-xs text-blue-600 font-inter">
                  {article.source}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
            <i className="fas fa-cloud-sun mr-2 text-blue-600"></i>
            Weather Forecast
          </h3>
          <div className="text-center mb-4">
            <p className="text-2xl font-bold text-gray-900 font-inter">
              {weather.temperature}°C
            </p>
            <p className="text-gray-600 font-inter">{weather.condition}</p>
            <p className="text-sm text-gray-500 font-inter">
              {weather.location}
            </p>
          </div>
          <div className="space-y-2">
            {weather.forecast.map((day, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-gray-600 font-inter">
                  {day.day}
                </span>
                <span className="text-sm text-gray-900 font-inter">
                  {day.high}°/{day.low}°
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderChat = () => (
    <div className="bg-white rounded-lg shadow-sm border h-[calc(100vh-200px)] flex flex-col">
      <div className="p-4 border-b">
        <h2 className="text-xl font-semibold text-gray-900 font-inter">
          <i className="fas fa-robot mr-2 text-blue-600"></i>
          AI Assistant
        </h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.type === "user" ? "justify-end" : "justify-start"
            }`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg font-inter ${
                message.type === "user"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-900"
              }`}
            >
              <p>{message.content}</p>
              <p
                className={`text-xs mt-1 ${
                  message.type === "user" ? "text-blue-100" : "text-gray-500"
                }`}
              >
                {message.timestamp.toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-100 px-4 py-2 rounded-lg">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div
                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.1s" }}
                ></div>
                <div
                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                ></div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t">
        <div className="flex space-x-2">
          <input
            type="text"
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Type your message..."
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <button
            onClick={startListening}
            disabled={isListening}
            className={`px-4 py-2 rounded-lg transition-colors ${
              isListening
                ? "bg-red-600 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            <i
              className={`fas ${isListening ? "fa-stop" : "fa-microphone"}`}
            ></i>
          </button>
          <button
            onClick={sendMessage}
            disabled={!currentMessage.trim() || isTyping}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <i className="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>
    </div>
  );

  const renderTasks = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 font-inter">
          <i className="fas fa-tasks mr-2 text-blue-600"></i>
          Task Management
        </h2>
        <div className="flex space-x-2">
          <select
            value={taskFilter}
            onChange={(e) => setTaskFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg font-inter"
          >
            <option value="all">All Tasks</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="flex space-x-2 mb-4">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && addTask()}
            placeholder="Add a new task..."
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <button
            onClick={addTask}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <i className="fas fa-plus"></i>
          </button>
        </div>

        <div className="space-y-3">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className="flex items-center justify-between p-3 border border-gray-200 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTask(task.id)}
                  className="rounded"
                />
                <div>
                  <p
                    className={`font-medium font-inter ${
                      task.completed
                        ? "line-through text-gray-500"
                        : "text-gray-900"
                    }`}
                  >
                    {task.title}
                  </p>
                  <div className="flex items-center space-x-2 mt-1">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-inter ${
                        task.priority === "high"
                          ? "bg-red-100 text-red-800"
                          : task.priority === "medium"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                      }`}
                    >
                      {task.priority}
                    </span>
                    <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-inter">
                      {task.category}
                    </span>
                    {task.dueDate && (
                      <span className="text-xs text-gray-500 font-inter">
                        Due: {task.dueDate}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <button className="text-gray-400 hover:text-red-600">
                <i className="fas fa-trash"></i>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCalendar = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 font-inter">
        <i className="fas fa-calendar mr-2 text-blue-600"></i>
        Calendar
      </h2>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
          Add New Event
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <input
            type="text"
            value={newEvent.title}
            onChange={(e) =>
              setNewEvent({ ...newEvent, title: e.target.value })
            }
            placeholder="Event title"
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <input
            type="date"
            value={newEvent.date}
            onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <input
            type="time"
            value={newEvent.time}
            onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <select
            value={newEvent.type}
            onChange={(e) => setNewEvent({ ...newEvent, type: e.target.value })}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          >
            <option value="meeting">Meeting</option>
            <option value="appointment">Appointment</option>
            <option value="reminder">Reminder</option>
            <option value="event">Event</option>
          </select>
        </div>
        <button
          onClick={addEvent}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-inter"
        >
          <i className="fas fa-plus mr-2"></i>
          Add Event
        </button>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
          Upcoming Events
        </h3>
        <div className="space-y-3">
          {events.map((event) => (
            <div
              key={event.id}
              className="flex items-center justify-between p-3 border border-gray-200 rounded-lg"
            >
              <div>
                <p className="font-medium text-gray-900 font-inter">
                  {event.title}
                </p>
                <p className="text-sm text-gray-600 font-inter">
                  <i className="fas fa-calendar mr-1"></i>
                  {event.date} at {event.time}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-inter">
                  {event.type}
                </span>
                <button className="text-gray-400 hover:text-red-600">
                  <i className="fas fa-trash"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderNotes = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 font-inter">
          <i className="fas fa-sticky-note mr-2 text-blue-600"></i>
          Notes
        </h2>
        <input
          type="text"
          value={noteSearch}
          onChange={(e) => setNoteSearch(e.target.value)}
          placeholder="Search notes..."
          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
        />
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
          Create New Note
        </h3>
        <div className="space-y-4">
          <input
            type="text"
            value={newNote.title}
            onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
            placeholder="Note title"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <textarea
            value={newNote.content}
            onChange={(e) =>
              setNewNote({ ...newNote, content: e.target.value })
            }
            placeholder="Note content"
            rows="4"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          ></textarea>
          <div className="flex items-center space-x-4">
            <select
              value={newNote.category}
              onChange={(e) =>
                setNewNote({ ...newNote, category: e.target.value })
              }
              className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
            >
              <option value="general">General</option>
              <option value="work">Work</option>
              <option value="personal">Personal</option>
              <option value="ideas">Ideas</option>
            </select>
            <button
              onClick={addNote}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-inter"
            >
              <i className="fas fa-plus mr-2"></i>
              Add Note
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredNotes.map((note) => (
          <div
            key={note.id}
            className="bg-white p-4 rounded-lg shadow-sm border"
          >
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-gray-900 font-inter">
                {note.title}
              </h3>
              <button className="text-gray-400 hover:text-red-600">
                <i className="fas fa-trash"></i>
              </button>
            </div>
            <p className="text-gray-700 text-sm mb-3 font-inter">
              {note.content}
            </p>
            <div className="flex items-center justify-between">
              <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-inter">
                {note.category}
              </span>
              <span className="text-xs text-gray-500 font-inter">
                {note.updatedAt.toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderEmail = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 font-inter">
        <i className="fas fa-envelope mr-2 text-blue-600"></i>
        Email Management
      </h2>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
          Compose Email
        </h3>
        <div className="space-y-4">
          <input
            type="email"
            value={emailDraft.to}
            onChange={(e) =>
              setEmailDraft({ ...emailDraft, to: e.target.value })
            }
            placeholder="To"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <input
            type="text"
            value={emailDraft.subject}
            onChange={(e) =>
              setEmailDraft({ ...emailDraft, subject: e.target.value })
            }
            placeholder="Subject"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          />
          <textarea
            value={emailDraft.body}
            onChange={(e) =>
              setEmailDraft({ ...emailDraft, body: e.target.value })
            }
            placeholder="Email body"
            rows="6"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-inter"
          ></textarea>
          <div className="flex space-x-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-inter">
              <i className="fas fa-paper-plane mr-2"></i>
              Send
            </button>
            <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-inter">
              <i className="fas fa-robot mr-2"></i>
              AI Assist
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
          Inbox
        </h3>
        <div className="space-y-3">
          {emails.map((email) => (
            <div
              key={email.id}
              className={`p-3 border rounded-lg ${
                email.read ? "bg-gray-50" : "bg-blue-50 border-blue-200"
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span
                      className={`font-medium font-inter ${
                        email.read ? "text-gray-700" : "text-gray-900"
                      }`}
                    >
                      {email.from}
                    </span>
                    {!email.read && (
                      <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                    )}
                  </div>
                  <p
                    className={`font-medium font-inter ${
                      email.read ? "text-gray-600" : "text-gray-900"
                    }`}
                  >
                    {email.subject}
                  </p>
                  <p className="text-sm text-gray-600 font-inter">
                    {email.preview}
                  </p>
                  <p className="text-xs text-gray-500 mt-1 font-inter">
                    {email.timestamp.toLocaleString()}
                  </p>
                </div>
                <div className="flex space-x-1">
                  <button className="text-gray-400 hover:text-blue-600">
                    <i className="fas fa-reply"></i>
                  </button>
                  <button className="text-gray-400 hover:text-red-600">
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderWeather = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 font-inter">
        <i className="fas fa-cloud-sun mr-2 text-blue-600"></i>
        Weather
      </h2>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="text-center mb-6">
          <h3 className="text-2xl font-semibold text-gray-900 mb-2 font-inter">
            {weather.location}
          </h3>
          <div className="flex items-center justify-center space-x-4 mb-4">
            <i className="fas fa-cloud-sun text-6xl text-yellow-500"></i>
            <div>
              <p className="text-4xl font-bold text-gray-900 font-inter">
                {weather.temperature}°C
              </p>
              <p className="text-lg text-gray-600 font-inter">
                {weather.condition}
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-sm text-gray-600 font-inter">Humidity</p>
              <p className="text-lg font-semibold text-gray-900 font-inter">
                {weather.humidity}%
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 font-inter">Wind Speed</p>
              <p className="text-lg font-semibold text-gray-900 font-inter">
                {weather.windSpeed} km/h
              </p>
            </div>
          </div>
        </div>

        <h4 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
          3-Day Forecast
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {weather.forecast.map((day, index) => (
            <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="font-medium text-gray-900 mb-2 font-inter">
                {day.day}
              </p>
              <i className="fas fa-cloud-sun text-2xl text-yellow-500 mb-2"></i>
              <p className="text-sm text-gray-600 font-inter">
                {day.condition}
              </p>
              <p className="font-semibold text-gray-900 font-inter">
                {day.high}° / {day.low}°
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderNews = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 font-inter">
        <i className="fas fa-newspaper mr-2 text-blue-600"></i>
        News Briefing
      </h2>

      <div className="space-y-4">
        {news.map((article) => (
          <div
            key={article.id}
            className="bg-white p-6 rounded-lg shadow-sm border"
          >
            <div className="flex items-start justify-between mb-3">
              <h3 className="text-lg font-semibold text-gray-900 font-inter">
                {article.title}
              </h3>
              <span className="text-xs text-blue-600 font-inter">
                {article.source}
              </span>
            </div>
            <p className="text-gray-700 mb-3 font-inter">{article.summary}</p>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500 font-inter">
                {article.timestamp.toLocaleString()}
              </span>
              <button className="text-blue-600 hover:text-blue-800 text-sm font-inter">
                Read more <i className="fas fa-external-link-alt ml-1"></i>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderHabits = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 font-inter">
        <i className="fas fa-chart-line mr-2 text-blue-600"></i>
        Habit Tracking
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {habits.map((habit) => (
          <div
            key={habit.id}
            className="bg-white p-6 rounded-lg shadow-sm border"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 font-inter">
                {habit.name}
              </h3>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-inter">
                {habit.category}
              </span>
            </div>

            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600 font-inter">
                  Progress
                </span>
                <span className="text-sm font-medium text-gray-900 font-inter">
                  {habit.completed}/{habit.target}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                  style={{
                    width: `${(habit.completed / habit.target) * 100}%`,
                  }}
                ></div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600 font-inter">
                  {habit.streak}
                </p>
                <p className="text-xs text-gray-600 font-inter">Day Streak</p>
              </div>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-inter">
                <i className="fas fa-plus mr-1"></i>
                Mark Done
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderGoals = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 font-inter">
        <i className="fas fa-bullseye mr-2 text-blue-600"></i>
        Goal Setting
      </h2>

      <div className="space-y-6">
        {goals.map((goal) => (
          <div
            key={goal.id}
            className="bg-white p-6 rounded-lg shadow-sm border"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 font-inter">
                  {goal.title}
                </h3>
                <p className="text-sm text-gray-600 font-inter">
                  Deadline: {goal.deadline}
                </p>
              </div>
              <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-inter">
                {goal.category}
              </span>
            </div>

            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600 font-inter">
                  Progress
                </span>
                <span className="text-sm font-medium text-gray-900 font-inter">
                  {goal.progress}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-purple-600 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${goal.progress}%` }}
                ></div>
              </div>
            </div>

            <div className="flex space-x-2">
              <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 font-inter">
                Update Progress
              </button>
              <button className="px-3 py-1 bg-gray-200 text-gray-700 rounded text-sm hover:bg-gray-300 font-inter">
                Add Milestone
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 font-inter">
        <i className="fas fa-chart-bar mr-2 text-blue-600"></i>
        Analytics & Insights
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
          <i className="fas fa-check-circle text-3xl text-green-600 mb-3"></i>
          <p className="text-2xl font-bold text-gray-900 font-inter">
            {analytics.tasksCompleted}
          </p>
          <p className="text-sm text-gray-600 font-inter">Tasks Completed</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
          <i className="fas fa-chart-line text-3xl text-blue-600 mb-3"></i>
          <p className="text-2xl font-bold text-gray-900 font-inter">
            {analytics.averageProductivity}%
          </p>
          <p className="text-sm text-gray-600 font-inter">Avg Productivity</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
          <i className="fas fa-fire text-3xl text-orange-600 mb-3"></i>
          <p className="text-2xl font-bold text-gray-900 font-inter">
            {analytics.streakDays}
          </p>
          <p className="text-sm text-gray-600 font-inter">Current Streak</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
          <i className="fas fa-sticky-note text-3xl text-purple-600 mb-3"></i>
          <p className="text-2xl font-bold text-gray-900 font-inter">
            {analytics.totalNotes}
          </p>
          <p className="text-sm text-gray-600 font-inter">Total Notes</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
          Productivity Trends
        </h3>
        <div className="h-64 flex items-center justify-center text-gray-500 font-inter">
          <i className="fas fa-chart-area text-4xl mr-3"></i>
          Productivity chart would be displayed here
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
            Weekly Summary
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600 font-inter">Tasks Completed</span>
              <span className="font-medium text-gray-900 font-inter">12</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 font-inter">Notes Created</span>
              <span className="font-medium text-gray-900 font-inter">8</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 font-inter">
                Habits Maintained
              </span>
              <span className="font-medium text-gray-900 font-inter">85%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 font-inter">Goals Progress</span>
              <span className="font-medium text-gray-900 font-inter">+15%</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 font-inter">
            AI Insights
          </h3>
          <div className="space-y-3">
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800 font-inter">
                <i className="fas fa-lightbulb mr-2"></i>
                You're most productive on Tuesday mornings
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <p className="text-sm text-green-800 font-inter">
                <i className="fas fa-trophy mr-2"></i>
                Great job maintaining your exercise streak!
              </p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <p className="text-sm text-yellow-800 font-inter">
                <i className="fas fa-exclamation-triangle mr-2"></i>
                Consider scheduling more breaks between tasks
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case "dashboard":
        return renderDashboard();
      case "chat":
        return renderChat();
      case "tasks":
        return renderTasks();
      case "calendar":
        return renderCalendar();
      case "notes":
        return renderNotes();
      case "email":
        return renderEmail();
      case "weather":
        return renderWeather();
      case "news":
        return renderNews();
      case "habits":
        return renderHabits();
      case "goals":
        return renderGoals();
      case "analytics":
        return renderAnalytics();
      default:
        return renderDashboard();
    }
  };

  return (
    <div
      className={`min-h-screen ${darkMode ? "bg-gray-900" : "bg-gray-50"} flex`}
    >
      {/* Sidebar */}
      <div
        className={`${sidebarOpen ? "w-64" : "w-16"} ${
          darkMode ? "bg-gray-800" : "bg-white"
        } shadow-lg transition-all duration-300 flex flex-col`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            {sidebarOpen && (
              <h1
                className={`text-xl font-bold ${
                  darkMode ? "text-white" : "text-gray-900"
                } font-inter`}
              >
                AI Assistant
              </h1>
            )}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className={`p-2 rounded-lg ${
                darkMode
                  ? "text-gray-300 hover:bg-gray-700"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <i className={`fas ${sidebarOpen ? "fa-times" : "fa-bars"}`}></i>
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-2">
            {sidebarItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`w-full flex items-center ${
                  sidebarOpen ? "px-3" : "justify-center"
                } py-2 rounded-lg transition-colors font-inter ${
                  activeSection === item.id
                    ? "bg-blue-600 text-white"
                    : darkMode
                    ? "text-gray-300 hover:bg-gray-700"
                    : "text-gray-700 hover:bg-gray-100"
                }`}
              >
                <i className={`${item.icon} ${sidebarOpen ? "mr-3" : ""}`}></i>
                {sidebarOpen && <span>{item.label}</span>}
              </button>
            ))}
          </div>
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center space-x-2">
            {sidebarOpen && (
              <div className="flex-1">
                <p
                  className={`text-sm font-medium ${
                    darkMode ? "text-white" : "text-gray-900"
                  } font-inter`}
                >
                  {user.name}
                </p>
                <p
                  className={`text-xs ${
                    darkMode ? "text-gray-400" : "text-gray-500"
                  } font-inter`}
                >
                  Premium User
                </p>
              </div>
            )}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-lg ${
                darkMode
                  ? "text-gray-300 hover:bg-gray-700"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <i className={`fas ${darkMode ? "fa-sun" : "fa-moon"}`}></i>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-6">{renderContent()}</div>
      </div>

      {/* Voice Listening Indicator */}
      {isListening && (
        <div className="fixed bottom-4 right-4 bg-red-600 text-white p-4 rounded-full shadow-lg animate-pulse">
          <i className="fas fa-microphone text-xl"></i>
        </div>
      )}
    </div>
  );
}

export default MainComponent;